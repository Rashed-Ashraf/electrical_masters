@echo off
title Electrical Masters Switchgear - Production Server
cd /d "%~dp0"

echo ========================================================
echo   Electrical Masters Switchgear - Production Server
echo ========================================================
echo.
echo Starting standalone production server...
echo Server running at: http://localhost:3000
echo Press Ctrl+C to stop.
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:3000"
node server.js
pause
