exports.id=873,exports.ids=[873],exports.modules={2543:(e,t,a)=>{let r={ea06127a3d8491322ba9d79a8fc587da4eb80d04:()=>Promise.resolve().then(a.bind(a,2643)).then(e=>e.sendEmail)};async function s(e,...t){return(await r[e]()).apply(null,t)}e.exports={ea06127a3d8491322ba9d79a8fc587da4eb80d04:s.bind(null,"ea06127a3d8491322ba9d79a8fc587da4eb80d04")}},3062:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});let r=(0,a(2881).Z)("CircleHelp",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]])},8998:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});let r=(0,a(2881).Z)("Clock",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]])},7027:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});let r=(0,a(2881).Z)("ExternalLink",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]])},5562:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});let r=(0,a(2881).Z)("MapPin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]])},617:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});let r=(0,a(2881).Z)("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]])},7650:(e,t,a)=>{"use strict";a.d(t,{Z:()=>r});let r=(0,a(2881).Z)("Navigation",[["polygon",{points:"3 11 22 2 13 21 11 13 3 11",key:"1ltx0t"}]])},3820:(e,t,a)=>{"use strict";a.d(t,{C:()=>r}),a(5424);var r=(0,a(6242).$)("ea06127a3d8491322ba9d79a8fc587da4eb80d04")},7026:(e,t,a)=>{"use strict";a.d(t,{g:()=>d});var r=a(326),s=a(7577),l=a(5562);let o=(0,a(2881).Z)("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);var i=a(7650),n=a(7027);let d=({className:e="",showTitle:t=!0})=>{let[a,d]=(0,s.useState)(!1),c="Nawab Mashkoor Town Kahna Kacha Road Kahna Nou Lahore- Pakistan",p="https://maps.app.goo.gl/q6mPFM3sRHoJjjVb8";return(0,r.jsxs)("div",{className:`w-full rounded-2xl overflow-hidden bg-[#002b40] border border-white/15 shadow-2xl flex flex-col ${e}`,children:[t&&(0,r.jsxs)("div",{className:"p-4 sm:p-5 bg-[#002233] border-b border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",children:[(0,r.jsxs)("div",{className:"flex items-center gap-3",children:[r.jsx("div",{className:"w-10 h-10 rounded-xl bg-[#0098da]/20 text-[#38bdf8] flex items-center justify-center flex-shrink-0 border border-[#0098da]/30 shadow-inner",children:r.jsx(l.Z,{className:"w-5 h-5 text-[#38bdf8] animate-bounce"})}),(0,r.jsxs)("div",{children:[(0,r.jsxs)("div",{className:"flex items-center gap-2",children:[r.jsx("h4",{className:"font-title text-white text-[15px] sm:text-[16px] font-bold",children:"Head Office & Manufacturing Works"}),r.jsx("span",{className:"hidden sm:inline-flex px-2 py-0.5 rounded-full bg-[#0098da]/20 text-[#38bdf8] font-technical text-[10px] font-bold uppercase tracking-wider",children:"Pinpoint Location"})]}),r.jsx("p",{className:"font-body text-[#c3e8ff] text-[12px] sm:text-[13px] leading-snug",children:c})]})]}),(0,r.jsxs)("div",{className:"flex items-center gap-2 w-full sm:w-auto",children:[r.jsx("button",{type:"button",onClick:()=>{navigator.clipboard.writeText(c),d(!0),setTimeout(()=>d(!1),2500)},className:"flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-[#e1f0f8] text-[12px] font-title font-semibold rounded-lg transition-all border border-white/10",title:"Copy company address",children:a?(0,r.jsxs)(r.Fragment,{children:[r.jsx(o,{className:"w-3.5 h-3.5 text-emerald-400"}),r.jsx("span",{className:"text-emerald-300",children:"Copied!"})]}):r.jsx("span",{children:"Copy Address"})}),(0,r.jsxs)("a",{href:p,target:"_blank",rel:"noopener noreferrer",className:"flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 bg-[#0098da] hover:bg-[#0084bd] active:bg-[#006f9e] text-white text-[12px] font-title font-bold rounded-lg shadow transition-all active:scale-95 whitespace-nowrap",children:[r.jsx(i.Z,{className:"w-3.5 h-3.5"}),r.jsx("span",{children:"Get Directions"}),r.jsx(n.Z,{className:"w-3 h-3 opacity-70"})]})]})]}),(0,r.jsxs)("div",{className:"relative w-full h-[280px] sm:h-[360px] md:h-[400px] bg-[#001c2b] group",children:[r.jsx("iframe",{title:"Electrical Masters Switchgear Location Map",src:"https://maps.google.com/maps?q=31.375889,74.352007&hl=en&z=16&output=embed",className:"w-full h-full border-0 filter saturate-110 contrast-105 pointer-events-none",loading:"lazy",allowFullScreen:!0,referrerPolicy:"no-referrer-when-downgrade"}),r.jsx("a",{href:p,target:"_blank",rel:"noopener noreferrer",className:"absolute inset-0 z-10 cursor-pointer transition-colors bg-black/0 group-hover:bg-[#0098da]/10",title:"Click to open location in Google Maps",children:r.jsx("span",{className:"sr-only",children:"Open location in Google Maps"})}),(0,r.jsxs)("div",{className:"absolute top-3 left-3 pointer-events-none z-20 bg-[#002233]/90 backdrop-blur-md border border-[#0098da]/40 text-white px-3.5 py-2 rounded-xl shadow-xl flex items-center gap-2.5 max-w-[90%]",children:[r.jsx("div",{className:"w-3 h-3 rounded-full bg-emerald-400 animate-pulse flex-shrink-0"}),(0,r.jsxs)("div",{className:"flex flex-col",children:[r.jsx("span",{className:"font-title text-[11px] font-bold text-white leading-tight",children:"Electrical Masters Switchgear Pvt. Ltd."}),r.jsx("span",{className:"font-technical text-[10px] text-[#38bdf8]",children:"Kahna Kacha Road, Kahna Nau, Lahore"})]})]}),r.jsx("div",{className:"absolute bottom-3 right-3 z-20 flex items-center gap-2",children:(0,r.jsxs)("a",{href:p,target:"_blank",rel:"noopener noreferrer",className:"px-3.5 py-2 bg-white text-[#002b40] font-title text-[12px] font-bold rounded-lg shadow-lg hover:bg-[#f0f7fb] transition-all flex items-center gap-1.5 cursor-pointer",children:[r.jsx("span",{children:"View Full Google Map"}),r.jsx(n.Z,{className:"w-3.5 h-3.5 text-[#0098da]"})]})})]})]})}},2643:(e,t,a)=>{"use strict";a.r(t),a.d(t,{sendEmail:()=>l});var r=a(7745);a(6461);var s=a(727);async function l(e){try{let t="",a="",r="",l="",o="",i="",n="";if(e instanceof FormData?(t=e.get("name")||"",a=e.get("email")||"",r=e.get("phone")||"",l=e.get("company")||"",o=e.get("message")||"",i=e.get("productTitle")||"",n=e.get("subject")||""):(t=e.name||"",a=e.email||"",r=e.phone||"",l=e.company||"",o=e.message||"",i=e.productTitle||"",n=e.subject||""),t=t.trim(),a=a.trim(),r=r.trim(),l=l.trim(),o=o.trim(),i=i.trim(),n=n.trim(),console.log("[SendEmail Action] Processing form submission:",{name:t,email:a,phone:r,company:l||"N/A",productTitle:i||"N/A",messageLength:o.length}),!t)return console.warn("[SendEmail Action Validation Error]: Full Name is missing."),{success:!1,error:"Full Name is required."};if(!a||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a))return console.warn("[SendEmail Action Validation Error]: Invalid email format:",a),{success:!1,error:"Please enter a valid email address."};if(!r)return console.warn("[SendEmail Action Validation Error]: Phone Number is missing."),{success:!1,error:"Phone Number is required."};if(!o)return console.warn("[SendEmail Action Validation Error]: Message is missing."),{success:!1,error:"Message content is required."};let d=process.env.RESEND_API_KEY;if(!d)return console.error("[SendEmail Action Error]: RESEND_API_KEY is not defined in environment variables."),{success:!1,error:"Email service configuration error. RESEND_API_KEY is missing."};let c=new s.R(d),p=process.env.RECIPIENT_EMAIL||process.env.CONTACT_EMAIL_TO||"shahid.iqbal@emswitchgear.com",m=new Date().toLocaleString("en-US",{timeZone:"Asia/Karachi",dateStyle:"full",timeStyle:"medium"}),x=n||(i?`Product Inquiry: ${i} - Electrical Masters`:"New Inquiry from Electrical Masters Website"),h=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f8fb; margin: 0; padding: 20px; color: #00283d; }
            .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; overflow: hidden; border: 1px solid #d3e4ee; box-shadow: 0 4px 16px rgba(0,77,109,0.08); }
            .header { background: #004d6d; padding: 24px; text-align: center; color: #ffffff; }
            .header h1 { margin: 0; font-size: 20px; text-transform: uppercase; letter-spacing: 1px; font-weight: 700; }
            .header p { margin: 6px 0 0 0; color: #c3e8ff; font-size: 13px; }
            .content { padding: 28px; }
            .section-title { font-size: 14px; font-weight: 700; color: #0098da; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; border-bottom: 2px solid #e1f0f8; padding-bottom: 6px; }
            .data-table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
            .data-table td { padding: 10px 0; border-bottom: 1px solid #edf4f8; font-size: 14px; }
            .data-table .label { font-weight: 600; color: #3e5261; width: 140px; }
            .data-table .value { color: #00283d; font-weight: 500; }
            .message-box { background: #f4f8fb; border-left: 4px solid #0098da; padding: 16px; border-radius: 4px; font-size: 14px; line-height: 1.6; color: #00283d; white-space: pre-wrap; word-wrap: break-word; }
            .footer { background: #003850; padding: 16px; text-align: center; font-size: 12px; color: #98cded; border-top: 1px solid rgba(255,255,255,0.1); }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Electrical Masters Switchgear</h1>
              <p>${i?`Product Inquiry: ${i}`:"New Website Inquiry"}</p>
            </div>
            <div class="content">
              <div class="section-title">Inquiry Details</div>
              <table class="data-table">
                ${i?`<tr>
                  <td class="label">Product / Model:</td>
                  <td class="value" style="color: #0098da; font-weight: 700;">${i}</td>
                </tr>`:""}
                <tr>
                  <td class="label">Customer Name:</td>
                  <td class="value">${t}</td>
                </tr>
                <tr>
                  <td class="label">Customer Email:</td>
                  <td class="value"><a href="mailto:${a}" style="color: #0098da; text-decoration: none; font-weight: 600;">${a}</a></td>
                </tr>
                <tr>
                  <td class="label">Customer Phone:</td>
                  <td class="value"><a href="tel:${r}" style="color: #00283d; text-decoration: none;">${r}</a></td>
                </tr>
                <tr>
                  <td class="label">Company Name:</td>
                  <td class="value">${l||"N/A"}</td>
                </tr>
              </table>

              <div class="section-title">Requirements &amp; Message</div>
              <div class="message-box">${o}</div>
            </div>
            <div class="footer">
              Received on: <strong>${m}</strong><br/>
              Target Recipient: <strong>${p}</strong>
            </div>
          </div>
        </body>
      </html>
    `,f=`${x}

Customer Name: ${t}
Customer Email: ${a}
Customer Phone: ${r}
Company: ${l||"N/A"}${i?`
Product: ${i}`:""}
Timestamp: ${m}

Requirements / Message:
${o}`,{data:u,error:g}=await c.emails.send({from:"Electrical Masters Switchgear <onboarding@resend.dev>",to:[p],replyTo:a,subject:x,html:h,text:f});if(g)return console.error("[SendEmail Action Resend API Error]:",g),{success:!1,error:g.message||"Failed to deliver email through Resend."};return console.log("[SendEmail Action Success] Email dispatched successfully:",u),{success:!0,message:"Thank you! We'll contact you soon.",data:u}}catch(e){return console.error("[SendEmail Action Exception]:",e),{success:!1,error:e?.message||"An unexpected error occurred while sending email."}}}(0,a(5723).h)([l]),(0,r.j)("ea06127a3d8491322ba9d79a8fc587da4eb80d04",l)}};