========================================================
Electrical Masters Switchgear - Production Build Package
========================================================

This is a standalone, pre-compiled production build of the
Electrical Masters Switchgear website.

HOW TO RUN:
-----------
1. Ensure Node.js (v18.17+ or v20+) is installed.
2. Double-click "start.bat" (on Windows)
   OR run in terminal:
   node server.js
3. Open your browser and visit:
   http://localhost:3000

DEPLOYMENT:
-----------
- Docker / VPS / Cloud: Run `node server.js`
- Port defaults to 3000. You can change it via environment variable:
  PORT=8080 node server.js
